<?php
define('ADMIN_EMAIL', 'admin@court7');
define('ADMIN_PASSWORD', '123456');
define('ADMIN_NAME', 'Administrator');