<?php

function db(): mysqli {
    static $conn = null;

    if ($conn === null) {
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $db   = 'court_system';

        $conn = mysqli_connect($host, $user, $pass, $db);

        if (!$conn) {
            die('Database connection failed: ' . mysqli_connect_error());
        }

        mysqli_set_charset($conn, 'utf8mb4');
    }

    return $conn;
}