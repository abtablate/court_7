<?php
namespace App\Core;

class Database {
    private $conn;
    public function __construct() {
        $this->conn = new \mysqli('localhost', 'root', '', 'court_system');
        if ($this->conn->connect_error) {
            die('Database connection failed: ' . $this->conn->connect_error);
        }
    }
    public function getConnection() {
        return $this->conn;
    }
}
